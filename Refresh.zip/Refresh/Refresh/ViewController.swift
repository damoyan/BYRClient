//
//  ViewController.swift
//  Refresh
//
//  Created by Yu Pengyang on 1/18/16.
//  Copyright © 2016 Yu Pengyang. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    var refreshView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("did load", "offset", tableView.contentOffset)
        print("did load", "inset", tableView.contentInset)
        print("did load", "size", tableView.contentSize)
        print("did load", "view height", tableView.frame.height)
        print("===========================================")
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear", "offset", tableView.contentOffset)
        print("viewWillAppear", "inset", tableView.contentInset)
        print("viewWillAppear", "size", tableView.contentSize)
        print("viewWillAppear", "view height", tableView.frame.height)
        print("===========================================")
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        print("viewDidAppear", "offset", tableView.contentOffset)
        print("viewDidAppear", "inset", tableView.contentInset)
        print("viewDidAppear", "size", tableView.contentSize)
        print("viewDidAppear", "view height", tableView.frame.height)
        print("===========================================")
        refreshView = UIView(frame: CGRect(x: 20, y: max(CGRectGetMaxY(tableView.frame) - tableView.contentInset.top, tableView.contentSize.height), width: 25, height: 25))
        refreshView!.backgroundColor = UIColor.greenColor()
        tableView.addSubview(refreshView!)
        print(refreshView!.frame)
        tableView.addObserver(self, forKeyPath: "contentSize", options: .New, context: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @objc @IBAction private func action(sender: AnyObject) {
        if tableView.contentInset.top == 64 {
            tableView.contentInset.top = 150
        } else {
            tableView.contentInset.top = 64
        }
    }
    
    var needLoadMore = false {
        didSet {
            if needLoadMore {
                loadData()
                tableView.contentInset.bottom += 40
            }
        }
    }
    var isLoading = false
    
    deinit {
        tableView.removeObserver(self, forKeyPath: "contentSize")
    }
}

extension ViewController {
    private func loadData() {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, Int64(15 * NSEC_PER_SEC)), dispatch_get_main_queue()) { () -> Void in
            UIView.animateWithDuration(0.25) { () -> Void in
                self.refreshView?.transform = CGAffineTransformIdentity
            }
            self.needLoadMore = false
            self.tableView.contentInset.bottom -= 40
        }
    }
}

extension ViewController {
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        guard tableView === object else { return }
        guard let k = keyPath where k == "contentSize" else { return }
        guard let newValue = change?[NSKeyValueChangeNewKey] as? NSValue else { return }
        let size = newValue.CGSizeValue()
        print("new Value: ", size)
        refreshView?.frame = CGRect(x: 20, y: max(CGRectGetMaxY(tableView.frame) - tableView.contentInset.top, tableView.contentSize.height), width: 25, height: 25)
    }
}

extension ViewController {
    
    override func scrollViewDidScroll(scrollView: UIScrollView) {
        let insetTop = scrollView.contentInset.top
        let height = scrollView.frame.height
        let contentHeight = scrollView.contentSize.height
        let offsetY = scrollView.contentOffset.y
        let threshold: CGFloat = 40
        if contentHeight + insetTop < height && offsetY + insetTop > threshold {
            refreshView?.transform = CGAffineTransformMakeTranslation(0, offsetY + insetTop - threshold)
            print(refreshView?.frame)
        } else if contentHeight + insetTop > height && offsetY + height - contentHeight > threshold {
            refreshView?.transform = CGAffineTransformMakeTranslation(0, offsetY + height - contentHeight - threshold)
            print(refreshView?.frame)
        } else {
            if !needLoadMore {
                refreshView?.transform = CGAffineTransformIdentity
            } else if contentHeight + insetTop < height {
                refreshView?.transform = CGAffineTransformMakeTranslation(0, offsetY + insetTop - threshold)
            } else if contentHeight + insetTop > height {
                refreshView?.transform = CGAffineTransformMakeTranslation(0, offsetY + height - contentHeight - threshold + ((contentHeight - offsetY - height) > 0 ? (contentHeight - offsetY - height) : 0))
            }
        }
    }
    
    override func scrollViewWillEndDragging(scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let insetTop = scrollView.contentInset.top
        let height = scrollView.frame.height
        let contentHeight = scrollView.contentSize.height
        let offsetY = scrollView.contentOffset.y
        let threshold: CGFloat = 60
        if contentHeight + insetTop < height && offsetY + insetTop > threshold {
            print(offsetY)
            print("need upload")
            needLoadMore = true
        } else if contentHeight + insetTop > height && offsetY + height - contentHeight > threshold {
            print(offsetY)
            needLoadMore = true
        }
    }
}

